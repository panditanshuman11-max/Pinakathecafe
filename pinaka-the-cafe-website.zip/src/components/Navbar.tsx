import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Menu, X } from "lucide-react";
import { Button } from "./ui/button";
import { cn } from "../utils/cn";

export interface NavItem {
  id: string;
  label: string;
}

interface NavbarProps {
  items: NavItem[];
  activeSection: string;
  onNavigate: (id: string) => void;
}

export function Navbar({ items, activeSection, onNavigate }: NavbarProps) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 24);
    handleScroll();
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleItemClick = (id: string) => {
    onNavigate(id);
    setOpen(false);
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 border-b transition-all duration-300",
        scrolled ? "border-[#d5b7a8] bg-[#f8f1de]/95 backdrop-blur-md" : "border-transparent bg-transparent"
      )}
    >
      <div className="mx-auto flex h-20 w-full max-w-7xl items-center justify-between px-4 sm:px-8">
        <button
          type="button"
          onClick={() => handleItemClick("home")}
          className="text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A82012]"
        >
          <span className="block font-display text-2xl leading-none text-[#A82012]">PINAKAA</span>
          <span className="block text-[10px] font-semibold tracking-[0.28em] text-[#3B0908]">THE CAFE</span>
        </button>

        <nav className="hidden items-center gap-7 lg:flex" aria-label="Primary">
          {items.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => handleItemClick(item.id)}
              className={cn(
                "text-sm font-semibold tracking-wide transition-colors hover:text-[#A82012]",
                activeSection === item.id ? "text-[#A82012]" : "text-[#3b312d]"
              )}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button onClick={() => handleItemClick("menu")} className="hidden lg:inline-flex">
            VIEW MENU
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-[#3B0908] lg:hidden"
            aria-label={open ? "Close navigation" : "Open navigation"}
            onClick={() => setOpen((current) => !current)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {open ? (
          <motion.nav
            key="mobile-nav"
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.25 }}
            className="border-t border-[#d5b7a8] bg-[#F8F1DE] px-5 pb-8 pt-4 lg:hidden"
            aria-label="Mobile"
          >
            <ul className="space-y-1">
              {items.map((item) => (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => handleItemClick(item.id)}
                    className={cn(
                      "w-full rounded-2xl px-4 py-3 text-left text-base font-semibold transition-colors",
                      activeSection === item.id ? "bg-[#A82012] text-[#F8F1DE]" : "text-[#201513] hover:bg-[#efe4d6]"
                    )}
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
            <Button onClick={() => handleItemClick("menu")} className="mt-4 w-full">
              VIEW MENU
            </Button>
          </motion.nav>
        ) : null}
      </AnimatePresence>
    </header>
  );
}