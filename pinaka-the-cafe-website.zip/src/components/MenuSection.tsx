import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { ArrowRight, RotateCcw, Search } from "lucide-react";
import { menuCategories, type MenuCategoryKey } from "../data/menu";
import { SectionHeading } from "./SectionHeading";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { cn } from "../utils/cn";

interface MenuSectionProps {
  onContactClick: () => void;
}

export function MenuSection({ onContactClick }: MenuSectionProps) {
  const [activeCategory, setActiveCategory] = useState<MenuCategoryKey>("Pizza");
  const [query, setQuery] = useState("");

  const selectedCategory = useMemo(
    () => menuCategories.find((category) => category.key === activeCategory) ?? menuCategories[0],
    [activeCategory]
  );

  const filteredItems = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return selectedCategory.items;
    return selectedCategory.items.filter((item) => {
      const joined = `${item.name} ${item.description ?? ""}`.toLowerCase();
      return joined.includes(term);
    });
  }, [query, selectedCategory]);

  return (
    <section className="bg-[#F8F1DE] py-20 md:py-28">
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-8">
        <SectionHeading
          eyebrow="Menu"
          title="THE PINAKAA MENU"
          subtitle="Something delicious for every craving."
        />

        <div className="mt-10 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="relative w-full md:max-w-md">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8a7d74]" />
            <Input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              className="pl-10"
              placeholder={`Search ${selectedCategory.key}`}
              aria-label="Search menu items"
            />
          </div>
          <Button variant="ghost" onClick={() => setQuery("")} className="w-fit text-[#3B0908]">
            <RotateCcw className="h-4 w-4" /> Reset Search
          </Button>
        </div>

        <div className="sticky top-20 z-20 mt-6 overflow-x-auto border-y border-[#dccbbb] bg-[#F8F1DE]/95 py-3 backdrop-blur-sm">
          <div className="flex min-w-max gap-2">
            {menuCategories.map((category) => (
              <button
                key={category.key}
                type="button"
                onClick={() => setActiveCategory(category.key)}
                className={cn(
                  "rounded-full px-5 py-2 text-sm font-semibold transition-colors",
                  activeCategory === category.key
                    ? "bg-[#A82012] text-[#F8F1DE]"
                    : "bg-[#efe4d6] text-[#3B0908] hover:bg-[#e6d6c4]"
                )}
              >
                {category.key}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-8 rounded-[2rem] bg-[#f4ecde] p-4 sm:p-7">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-[#d7c7b6] pb-4">
            <h3 className="font-display text-3xl text-[#201513] md:text-4xl">{selectedCategory.key}</h3>
            <div className="text-right text-sm text-[#6e5e55]">
              {selectedCategory.priceHint ? <p>Price labels: {selectedCategory.priceHint}</p> : null}
              {selectedCategory.note ? <p>{selectedCategory.note}</p> : null}
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={`${selectedCategory.key}-${query}`}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -14 }}
              transition={{ duration: 0.25 }}
              className="grid gap-x-10 md:grid-cols-2"
            >
              {filteredItems.map((item) => (
                <article key={item.name} className="border-b border-[#ddcebe] py-4">
                  <div className="flex items-start justify-between gap-3">
                    <h4 className="font-semibold text-[#201513]">{item.name}</h4>
                    <p className="shrink-0 font-bold text-[#A82012]">{item.price}</p>
                  </div>
                  {item.description ? <p className="mt-1 text-sm text-[#6b5f58]">{item.description}</p> : null}
                </article>
              ))}
              {!filteredItems.length ? (
                <p className="py-6 text-sm text-[#6b5f58]">No items matched your search in this category.</p>
              ) : null}
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="mt-8 flex justify-center md:justify-start">
          <Button onClick={onContactClick} className="group">
            CONTACT US TO ORDER <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Button>
        </div>
      </div>
    </section>
  );
}