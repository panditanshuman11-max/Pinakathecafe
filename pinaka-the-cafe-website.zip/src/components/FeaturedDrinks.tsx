import { motion } from "motion/react";
import { ArrowRight } from "lucide-react";
import { SectionHeading } from "./SectionHeading";
import { Button } from "./ui/button";

interface FeaturedDrinksProps {
  onExploreMenu: () => void;
}

const drinks = [
  {
    name: "Hot Coffee",
    price: "₹69",
    description: "Comforting and aromatic, a go-to cup any time of day.",
    image: "https://images.unsplash.com/photo-1511920170033-f8396924c348?auto=format&fit=crop&w=1000&q=80",
  },
  {
    name: "Cold Coffee",
    price: "₹169",
    description: "Smooth, chilled and balanced for warm afternoons.",
    image: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=1000&q=80",
  },
  {
    name: "Mango Slush",
    price: "₹69",
    description: "Bright fruit flavour with a cool refreshing finish.",
    image: "https://images.unsplash.com/photo-1610970881699-44a5587cabec?auto=format&fit=crop&w=1000&q=80",
  },
  {
    name: "Lime Soda",
    price: "₹129",
    description: "Crisp and fizzy with citrus notes that wake up the palate.",
    image: "https://images.unsplash.com/photo-1523905330026-b8bd1f5f320e?auto=format&fit=crop&w=1000&q=80",
  },
  {
    name: "Virgin Mojito",
    price: "₹149",
    description: "Minty and sparkling, crafted for a clean, bright sip.",
    image: "https://images.unsplash.com/photo-1551538827-9c037cb4f32a?auto=format&fit=crop&w=1000&q=80",
  },
  {
    name: "Masala Cold Drink",
    price: "₹99",
    description: "A fizzy favourite with bold masala-style character.",
    image: "https://images.unsplash.com/photo-1536935338788-846bb9981813?auto=format&fit=crop&w=1000&q=80",
  },
];

export function FeaturedDrinks({ onExploreMenu }: FeaturedDrinksProps) {
  return (
    <section className="bg-[#3B0908] py-20 md:py-28">
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-8">
        <SectionHeading
          light
          eyebrow="Signature Drinks"
          title="YOUR NEXT FAVOURITE SIP."
          subtitle="Coffee classics and refreshing favourites, made for every kind of craving."
        />

        <div className="mt-12 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {drinks.map((drink, index) => (
            <motion.article
              key={drink.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.25 }}
              transition={{ duration: 0.45, delay: index * 0.06 }}
              className="group overflow-hidden rounded-3xl border border-[#6a3737] bg-[#4e1715]/70"
            >
              <div className="relative h-52 overflow-hidden">
                <img
                  src={drink.image}
                  alt={`Illustrative drink image for ${drink.name}`}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="space-y-3 p-5">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-display text-2xl text-[#f9ece2]">{drink.name}</h3>
                  <p className="text-lg font-bold text-[#ffe4cc]">{drink.price}</p>
                </div>
                <p className="text-sm text-[#f0d8cc]">{drink.description}</p>
                <Button variant="secondary" size="sm" onClick={onExploreMenu} className="group/btn">
                  Explore Menu <ArrowRight className="h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
                </Button>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}