import * as React from "react";
import { cn } from "../../utils/cn";

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {}

const Input = React.forwardRef<HTMLInputElement, InputProps>(({ className, type = "text", ...props }, ref) => {
  return (
    <input
      ref={ref}
      type={type}
      className={cn(
        "flex h-11 w-full rounded-full border border-[#d4c5b2] bg-[#fffaf2] px-4 py-2 text-sm text-[#201513] shadow-sm transition-colors placeholder:text-[#8a7d74] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A82012] focus-visible:ring-offset-2",
        className
      )}
      {...props}
    />
  );
});

Input.displayName = "Input";

export { Input };