import { contactInfo } from "../data/menu";

interface FooterProps {
  onNavigate: (id: string) => void;
}

const footerLinks = [
  { id: "home", label: "Home" },
  { id: "story", label: "Our Story" },
  { id: "menu", label: "Menu" },
  { id: "favourites", label: "Favourites" },
  { id: "contact", label: "Contact" },
];

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-[#2b0606] py-14 text-[#f4e7dc]">
      <div className="mx-auto grid w-full max-w-7xl gap-10 px-4 sm:px-8 md:grid-cols-3">
        <div>
          <p className="font-display text-4xl leading-none">PINAKAA</p>
          <p className="mt-1 text-xs font-semibold uppercase tracking-[0.3em] text-[#ddc5b9]">THE CAFE</p>
          <p className="mt-4 max-w-xs text-sm text-[#e6d2c7]">GOOD FOOD. GREAT COFFEE. BETTER MOMENTS.</p>
        </div>

        <nav aria-label="Footer" className="space-y-2">
          {footerLinks.map((link) => (
            <button
              key={link.id}
              type="button"
              onClick={() => onNavigate(link.id)}
              className="block text-left text-sm font-semibold tracking-wide text-[#f4e7dc] hover:text-white"
            >
              {link.label}
            </button>
          ))}
        </nav>

        <div className="space-y-2 text-sm">
          <a href={`tel:${contactInfo.phone.replace(/\s+/g, "")}`} className="block hover:text-white">
            {contactInfo.phone}
          </a>
          <a href={`mailto:${contactInfo.email}`} className="block hover:text-white">
            {contactInfo.email.toLowerCase()}
          </a>
        </div>
      </div>
      <div className="mx-auto mt-10 w-full max-w-7xl border-t border-[#5f2e2b] px-4 pt-6 text-xs text-[#d8bfb1] sm:px-8">
        <p>© {new Date().getFullYear()} Pinakaa The Cafe. All rights reserved.</p>
      </div>
    </footer>
  );
}