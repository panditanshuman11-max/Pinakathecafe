import { motion } from "motion/react";
import { Mail, Phone, ArrowUpRight } from "lucide-react";
import { SectionHeading } from "./SectionHeading";
import { Button } from "./ui/button";
import { contactInfo } from "../data/menu";

export function ContactSection() {
  const emailLower = contactInfo.email.toLowerCase();
  const telLink = `tel:${contactInfo.phone.replace(/\s+/g, "")}`;

  return (
    <section className="bg-[#F8F1DE] py-20 md:py-28">
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-8">
        <SectionHeading
          eyebrow="Contact"
          title="LET'S MAKE IT A PINAKAA MOMENT."
          subtitle="Reach out for orders, menu details, and quick cafe enquiries."
        />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.45 }}
          className="mt-10 grid gap-4 rounded-[2rem] bg-[#efe4d6] p-6 md:grid-cols-2 md:p-8"
        >
          <a
            href={telLink}
            className="group rounded-2xl border border-[#d5b9a5] bg-[#fffaf2] p-5 transition-colors hover:bg-[#fff3e4] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A82012]"
          >
            <div className="flex items-center gap-3 text-[#A82012]">
              <Phone className="h-5 w-5" />
              <span className="text-xs font-semibold uppercase tracking-[0.2em]">Phone</span>
            </div>
            <p className="mt-3 text-xl font-semibold text-[#201513]">{contactInfo.phone}</p>
            <span className="mt-4 inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-[0.18em] text-[#3B0908]">
              Call now <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </span>
          </a>

          <a
            href={`mailto:${contactInfo.email}`}
            className="group rounded-2xl border border-[#d5b9a5] bg-[#fffaf2] p-5 transition-colors hover:bg-[#fff3e4] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A82012]"
          >
            <div className="flex items-center gap-3 text-[#A82012]">
              <Mail className="h-5 w-5" />
              <span className="text-xs font-semibold uppercase tracking-[0.2em]">Email</span>
            </div>
            <p className="mt-3 break-all text-xl font-semibold text-[#201513]">{emailLower}</p>
            <span className="mt-4 inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-[0.18em] text-[#3B0908]">
              Send email <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </span>
          </a>
        </motion.div>

        <div className="mt-8 flex flex-wrap gap-3">
          <Button asChild>
            <a href={telLink}>GET IN TOUCH</a>
          </Button>
          <Button variant="outline" asChild className="border-[#3B0908]">
            <a href={`mailto:${contactInfo.email}`}>EMAIL PINAKAA</a>
          </Button>
        </div>
      </div>
    </section>
  );
}