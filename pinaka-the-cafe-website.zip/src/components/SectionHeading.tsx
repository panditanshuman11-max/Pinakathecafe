import { motion } from "motion/react";
import { cn } from "../utils/cn";

interface SectionHeadingProps {
  title: string;
  subtitle?: string;
  eyebrow?: string;
  light?: boolean;
  className?: string;
}

export function SectionHeading({ title, subtitle, eyebrow, light, className }: SectionHeadingProps) {
  return (
    <motion.header
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.55 }}
      className={cn("space-y-4", className)}
    >
      {eyebrow ? (
        <p className={cn("text-xs font-semibold uppercase tracking-[0.25em]", light ? "text-[#f0d8cc]" : "text-[#A82012]")}>{eyebrow}</p>
      ) : null}
      <h2 className={cn("font-display text-4xl leading-[0.95] md:text-6xl", light ? "text-[#F8F1DE]" : "text-[#201513]")}>{title}</h2>
      {subtitle ? (
        <p className={cn("max-w-2xl text-base md:text-lg", light ? "text-[#f4e8e0]" : "text-[#5f524b]")}>{subtitle}</p>
      ) : null}
    </motion.header>
  );
}