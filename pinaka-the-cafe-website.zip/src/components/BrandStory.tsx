import { motion } from "motion/react";
import { SectionHeading } from "./SectionHeading";

export function BrandStory() {
  return (
    <section className="bg-[#A82012] py-20 md:py-28">
      <div className="mx-auto grid w-full max-w-7xl gap-12 px-4 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
        <motion.figure
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.6 }}
          className="overflow-hidden rounded-[2rem]"
        >
          <img
            src="https://images.unsplash.com/photo-1521017432531-fbd92d768814?auto=format&fit=crop&w=1200&q=80"
            alt="Illustrative lifestyle coffee table scene"
            className="h-full min-h-[20rem] w-full object-cover"
            loading="lazy"
          />
        </motion.figure>

        <div className="space-y-7">
          <SectionHeading
            light
            eyebrow="Our Story"
            title="GOOD COFFEE. GREAT MOMENTS."
            subtitle="At Pinakaa The Cafe, every visit is an opportunity to slow down, enjoy something delicious, and make an ordinary moment special."
          />
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.55, delay: 0.1 }}
            className="font-serif text-lg italic text-[#f9e8de]"
          >
            An everyday pause, designed with warmth, flavour, and thoughtful details.
          </motion.p>
        </div>
      </div>
    </section>
  );
}