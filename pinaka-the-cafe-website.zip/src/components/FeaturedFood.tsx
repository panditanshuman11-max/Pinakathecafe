import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import { SectionHeading } from "./SectionHeading";
import { Button } from "./ui/button";

interface FeaturedFoodProps {
  onMenuClick: () => void;
}

const featuredFoodItems = [
  {
    name: "Margherita Pizza",
    price: "₹149 / ₹299",
    category: "Pizza",
    image: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?auto=format&fit=crop&w=1200&q=80",
    large: true,
  },
  {
    name: "Paneer Burger",
    price: "₹199",
    category: "Burger & Sandwich",
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=900&q=80",
  },
  {
    name: "French Fries",
    price: "₹99",
    category: "Starter",
    image: "https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?auto=format&fit=crop&w=900&q=80",
  },
  {
    name: "Veg Steamed Momos",
    price: "₹149",
    category: "Starter",
    image: "https://images.unsplash.com/photo-1621434991751-b0f0dcb36dba?auto=format&fit=crop&w=900&q=80",
  },
  {
    name: "Alfredo",
    price: "₹399",
    category: "Pasta",
    image: "https://images.unsplash.com/photo-1645112411341-6c4fd023714a?auto=format&fit=crop&w=900&q=80",
  },
  {
    name: "Waffle with Ice Cream",
    price: "₹199",
    category: "Dessert",
    image: "https://images.unsplash.com/photo-1505253216365-8f1f6f05d26c?auto=format&fit=crop&w=900&q=80",
  },
];

export function FeaturedFood({ onMenuClick }: FeaturedFoodProps) {
  return (
    <section className="bg-[#efe4d6] py-20 md:py-28">
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-8">
        <SectionHeading
          eyebrow="Featured Food"
          title="MADE FOR YOUR CRAVINGS."
          subtitle="A quick look at some of the most-loved bites from the Pinakaa menu."
        />

        <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {featuredFoodItems.map((item, index) => (
            <motion.article
              key={item.name}
              initial={{ opacity: 0, y: 22 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.25 }}
              transition={{ duration: 0.45, delay: index * 0.04 }}
              className={item.large ? "md:col-span-2 md:row-span-2" : ""}
            >
              <button
                type="button"
                onClick={onMenuClick}
                className="group h-full w-full overflow-hidden rounded-3xl bg-[#3B0908] text-left"
              >
                <div className="relative h-52 overflow-hidden md:h-full md:min-h-[17rem]">
                  <img
                    src={item.image}
                    alt={`Illustrative food image for ${item.name}`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1b0907] via-[#1b0907]/35 to-transparent" />
                  <div className="absolute bottom-0 left-0 w-full p-5 text-[#f9f1e8]">
                    <p className="text-xs uppercase tracking-[0.2em] text-[#f2d4bf]">{item.category}</p>
                    <h3 className="mt-1 font-display text-2xl leading-tight">{item.name}</h3>
                    <div className="mt-2 flex items-center justify-between">
                      <p className="font-semibold">{item.price}</p>
                      <span className="inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-[0.17em]">
                        View Menu <ArrowUpRight className="h-4 w-4" />
                      </span>
                    </div>
                  </div>
                </div>
              </button>
            </motion.article>
          ))}
        </div>

        <div className="mt-8">
          <Button onClick={onMenuClick}>Go To Full Menu</Button>
        </div>
      </div>
    </section>
  );
}