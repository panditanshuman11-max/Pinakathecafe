import { motion, useReducedMotion } from "motion/react";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { Button } from "./ui/button";

interface HeroProps {
  onMenuClick: () => void;
  onStoryClick: () => void;
}

const beanImages = [
  "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=800&q=80",
  "https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=800&q=80",
];

export function Hero({ onMenuClick, onStoryClick }: HeroProps) {
  const reduceMotion = useReducedMotion();

  return (
    <section className="relative min-h-[100svh] overflow-hidden bg-[#F8F1DE] pt-24">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1920&q=80"
          alt="Illustrative coffee cup with rich espresso crema"
          className="h-full w-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#f8f1de]/92 via-[#f8f1de]/82 to-[#f8f1de]/42" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#f8f1de] via-transparent to-[#f8f1de]/20" />
      </div>

      <motion.div
        aria-hidden="true"
        initial={reduceMotion ? undefined : { scale: 0.85, opacity: 0 }}
        animate={reduceMotion ? undefined : { scale: 1, opacity: 0.22 }}
        transition={{ duration: 0.9 }}
        className="absolute right-[-12%] top-[12%] h-[30rem] w-[30rem] rounded-full bg-[#A82012] blur-3xl"
      />

      <div className="relative mx-auto flex min-h-[calc(100svh-6rem)] w-full max-w-7xl flex-col justify-center px-4 pb-20 sm:px-8">
        <motion.p
          initial={reduceMotion ? undefined : { opacity: 0, y: 16 }}
          animate={reduceMotion ? undefined : { opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="text-xs font-semibold uppercase tracking-[0.26em] text-[#A82012]"
        >
          Crafted For Your Everyday
        </motion.p>

        <div className="mt-4 max-w-4xl">
          <motion.h1
            initial={reduceMotion ? undefined : { opacity: 0 }}
            animate={reduceMotion ? undefined : { opacity: 1 }}
            transition={{ duration: 0.45 }}
            className="font-display text-[17vw] leading-[0.85] text-[#A82012] sm:text-[7.5rem] md:text-[9rem]"
          >
            <motion.span
              className="block"
              initial={reduceMotion ? undefined : { y: 40 }}
              animate={reduceMotion ? undefined : { y: 0 }}
              transition={{ duration: 0.55, delay: 0.2 }}
            >
              PINAKAA
            </motion.span>
            <motion.span
              className="block pl-1 text-[6vw] tracking-[0.34em] text-[#3B0908] sm:text-[2rem] md:text-[2.2rem]"
              initial={reduceMotion ? undefined : { y: 34 }}
              animate={reduceMotion ? undefined : { y: 0 }}
              transition={{ duration: 0.55, delay: 0.32 }}
            >
              THE CAFE
            </motion.span>
          </motion.h1>
        </div>

        <motion.div
          initial={reduceMotion ? undefined : { opacity: 0, y: 22 }}
          animate={reduceMotion ? undefined : { opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.42 }}
          className="mt-8 max-w-xl space-y-5"
        >
          <h2 className="font-display text-4xl leading-[0.96] text-[#201513] md:text-6xl">YOUR EVERYDAY COFFEE RITUAL.</h2>
          <p className="text-base text-[#554740] md:text-lg">
            From comforting coffee classics to delicious bites, discover your next favourite moment at Pinakaa The Cafe.
          </p>
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#3B0908]">Coffee • Food • Good Moments</p>
          <div className="flex flex-wrap gap-3">
            <Button onClick={onMenuClick} className="group">
              EXPLORE OUR MENU <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Button>
            <Button variant="outline" onClick={onStoryClick} className="group border-[#3B0908]">
              DISCOVER PINAKAA <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </Button>
          </div>
        </motion.div>

        <div className="pointer-events-none absolute bottom-6 right-5 hidden gap-4 md:flex">
          {beanImages.map((image, idx) => (
            <motion.img
              key={image}
              src={image}
              alt="Illustrative roasted coffee beans"
              className="h-20 w-20 rounded-full border border-[#e7d6c8] object-cover"
              initial={reduceMotion ? undefined : { opacity: 0, y: 20 }}
              animate={reduceMotion ? undefined : { opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.5 + idx * 0.1 }}
            />
          ))}
        </div>
      </div>
    </section>
  );
}