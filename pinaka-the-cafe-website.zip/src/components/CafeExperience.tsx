import { useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { Coffee, Users, Utensils } from "lucide-react";
import { SectionHeading } from "./SectionHeading";

const highlights = [
  { icon: Coffee, title: "Enjoy Coffee", description: "Settle in with your daily cup or an iced favourite." },
  { icon: Users, title: "Catch Up", description: "Meet friends and share relaxed conversation over bites." },
  { icon: Utensils, title: "Quick Meal", description: "Take a break and enjoy comforting food with easy pace." },
];

export function CafeExperience() {
  const sectionRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start end", "end start"] });
  const imageY = useTransform(scrollYProgress, [0, 1], [40, -40]);

  return (
    <section ref={sectionRef} className="overflow-hidden bg-[#3B0908] py-20 md:py-28">
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-8">
        <SectionHeading
          light
          eyebrow="Atmosphere"
          title="YOUR LITTLE ESCAPE."
          subtitle="A warm pause for coffee, conversation, a quick bite, or a little reset in the middle of your day."
        />

        <div className="mt-12 grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
          <motion.figure style={{ y: imageY }} className="overflow-hidden rounded-[2rem]">
            <img
              src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=1400&q=80"
              alt="Illustrative cafe interior atmosphere with coffee setup"
              loading="lazy"
              className="h-[26rem] w-full object-cover"
            />
          </motion.figure>

          <div className="space-y-4">
            {highlights.map((item, index) => (
              <motion.article
                key={item.title}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.4, delay: index * 0.09 }}
                className="rounded-2xl border border-[#724040] bg-[#4a1817] p-5"
              >
                <div className="flex items-start gap-3">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-[#f3e2d4] text-[#A82012]">
                    <item.icon className="h-5 w-5" />
                  </span>
                  <div>
                    <h3 className="font-display text-2xl text-[#f9ece2]">{item.title}</h3>
                    <p className="mt-1 text-sm text-[#f0d8cc]">{item.description}</p>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}