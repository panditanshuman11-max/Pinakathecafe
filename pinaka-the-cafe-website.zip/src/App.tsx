import { useEffect, useMemo, useState } from "react";
import { motion, useScroll, useSpring } from "motion/react";
import { Phone } from "lucide-react";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { BrandStory } from "./components/BrandStory";
import { FeaturedDrinks } from "./components/FeaturedDrinks";
import { MenuSection } from "./components/MenuSection";
import { FeaturedFood } from "./components/FeaturedFood";
import { CafeExperience } from "./components/CafeExperience";
import { ContactSection } from "./components/ContactSection";
import { Footer } from "./components/Footer";
import { contactInfo } from "./data/menu";

const navItems = [
  { id: "home", label: "Home" },
  { id: "story", label: "Our Story" },
  { id: "menu", label: "Menu" },
  { id: "favourites", label: "Favourites" },
  { id: "contact", label: "Contact" },
];

export default function App() {
  const [activeSection, setActiveSection] = useState("home");
  const { scrollYProgress } = useScroll();
  const progressScaleX = useSpring(scrollYProgress, { stiffness: 140, damping: 28, mass: 0.25 });

  useEffect(() => {
    document.title = "Pinakaa The Cafe | Coffee, Food & Good Moments";
    const description =
      "Pinakaa The Cafe serves coffee classics, refreshing drinks, pizzas, pasta, starters, desserts and more for your everyday coffee ritual.";

    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.setAttribute("name", "description");
      document.head.appendChild(meta);
    }
    meta.setAttribute("content", description);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActiveSection(entry.target.id);
        });
      },
      { threshold: 0.45, rootMargin: "-20% 0px -35% 0px" }
    );

    navItems.forEach((item) => {
      const node = document.getElementById(item.id);
      if (node) observer.observe(node);
    });

    return () => observer.disconnect();
  }, []);

  const onNavigate = (id: string) => {
    const section = document.getElementById(id);
    if (section) {
      section.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const telHref = useMemo(() => `tel:${contactInfo.phone.replace(/\s+/g, "")}`, []);

  return (
    <div className="overflow-x-hidden bg-[#F8F1DE] text-[#201513]">
      <motion.div style={{ scaleX: progressScaleX }} className="fixed left-0 top-0 z-[60] h-1 w-full origin-left bg-[#A82012]" />
      <Navbar items={navItems} activeSection={activeSection} onNavigate={onNavigate} />

      <main>
        <section id="home" aria-label="Hero">
          <Hero onMenuClick={() => onNavigate("menu")} onStoryClick={() => onNavigate("story")} />
        </section>

        <section id="story" aria-label="Brand story">
          <BrandStory />
        </section>

        <section id="drinks" aria-label="Signature drinks">
          <FeaturedDrinks onExploreMenu={() => onNavigate("menu")} />
        </section>

        <section id="menu" aria-label="Interactive menu">
          <MenuSection onContactClick={() => onNavigate("contact")} />
        </section>

        <section id="favourites" aria-label="Featured food">
          <FeaturedFood onMenuClick={() => onNavigate("menu")} />
        </section>

        <section id="experience" aria-label="Cafe experience">
          <CafeExperience />
        </section>

        <section id="contact" aria-label="Contact">
          <ContactSection />
        </section>
      </main>

      <Footer onNavigate={onNavigate} />

      <a
        href={telHref}
        className="fixed bottom-4 right-4 z-40 inline-flex h-12 items-center gap-2 rounded-full bg-[#A82012] px-5 text-xs font-semibold uppercase tracking-[0.16em] text-[#F8F1DE] shadow-lg shadow-[#A82012]/30 md:hidden"
      >
        <Phone className="h-4 w-4" /> Contact
      </a>
    </div>
  );
}
