export type MenuCategoryKey =
  | "Pizza"
  | "Burger & Sandwich"
  | "Dessert"
  | "Starter"
  | "Pasta"
  | "Drinks";

export interface MenuItem {
  name: string;
  price: string;
  description?: string;
}

export interface MenuCategory {
  key: MenuCategoryKey;
  note?: string;
  priceHint?: string;
  items: MenuItem[];
}

export const menuCategories: MenuCategory[] = [
  {
    key: "Pizza",
    priceHint: "M/L",
    items: [
      {
        name: "Margherita Pizza",
        price: "₹149 / ₹299",
        description: "Classic Margherita, topped with marinara sauce, mozzarella and cheddar.",
      },
      {
        name: "Red and Black Pizza",
        price: "₹199 / ₹369",
        description: "Fresh dough with tomato and olives on top, mozzarella and cheddar.",
      },
      {
        name: "Farm Fresh Pizza",
        price: "₹219 / ₹399",
        description: "Fresh dough with onion, corn, tomato and capsicum on top, mozzarella and cheddar.",
      },
      {
        name: "Cottage Pizza",
        price: "₹249 / ₹499",
        description: "Fresh dough with vegetables and paneer on top, mozzarella cheese with Parmesan.",
      },
      {
        name: "Pizza Exotica",
        price: "₹269 / ₹519",
        description:
          "Fresh dough with exotic vegetables on top and mozzarella cheese with Parmesan. Comes with dip.",
      },
    ],
  },
  {
    key: "Burger & Sandwich",
    note: "Extra cheese: ₹20.",
    items: [
      { name: "Veg Burger", price: "₹149" },
      { name: "Cheese Burger", price: "₹189" },
      { name: "Paneer Burger", price: "₹199" },
      { name: "Classic Veg Sandwich", price: "₹149" },
      { name: "Grilled Cheese Sandwich", price: "₹179" },
      { name: "Club Sandwich", price: "₹229" },
      { name: "Veggie Wrap", price: "₹79" },
      { name: "Cheesy Wrap", price: "₹99" },
      { name: "Veg 6-Inch Sub", price: "₹169" },
      { name: "Paneer 6-Inch Sub", price: "₹199" },
      { name: "Special 6-Inch Sub", price: "₹249" },
    ],
  },
  {
    key: "Dessert",
    items: [
      { name: "Ice Cream", price: "₹179" },
      { name: "Waffle with Ice Cream", price: "₹199" },
      { name: "Cheese Cake Slice", price: "₹199" },
      { name: "Brownie Sizzler", price: "₹199" },
    ],
  },
  {
    key: "Starter",
    priceHint: "H/F",
    items: [
      { name: "Classic Noodles", price: "₹149" },
      { name: "Chilli Garlic Noodles", price: "₹169" },
      { name: "Hakka Noodles", price: "₹179" },
      { name: "Classic Fried Rice", price: "₹139" },
      { name: "Schezwan Fried Rice", price: "₹159" },
      { name: "Veg Steamed Momos", price: "₹149" },
      { name: "French Fries", price: "₹99" },
      { name: "Dry Chilly Paneer", price: "₹189 / ₹339" },
      { name: "Chilly Paneer Gravy", price: "₹179 / ₹319" },
      { name: "Manchurian Dry/Gravy", price: "₹169 / ₹299" },
      { name: "Cheese Garlic Bread", price: "₹149" },
      { name: "Olive Garlic Bread", price: "₹169" },
      { name: "Crispy Momos", price: "₹169" },
      { name: "Kurkure Momos", price: "₹199" },
    ],
  },
  {
    key: "Pasta",
    items: [
      {
        name: "Plain Arrabiata",
        price: "₹349",
        description: "Classic Arrabiata red sauce with Parmesan cheese on top.",
      },
      {
        name: "Alfredo",
        price: "₹399",
        description: "Classic Alfredo white sauce with Parmesan cheese on top.",
      },
      {
        name: "Creamy Arrabiata",
        price: "₹399",
        description: "Creamy Arrabiata sauce with Parmesan cheese on top.",
      },
    ],
  },
  {
    key: "Drinks",
    items: [
      { name: "Bottled Water", price: "₹20" },
      { name: "Cold Drink", price: "₹50" },
      { name: "Mango Slush", price: "₹69" },
      { name: "Masala Cold Drink", price: "₹99" },
      { name: "Lime Soda", price: "₹129" },
      { name: "Virgin Mojito", price: "₹149" },
      { name: "Cold Coffee", price: "₹169" },
      { name: "Hot Coffee", price: "₹69" },
    ],
  },
];

export const contactInfo = {
  phone: "+91 7991850018",
  email: "PINAKAATHECAFE@GMAIL.COM",
};